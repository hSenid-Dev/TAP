<?php
/**
 *   (C) Copyright 1997-2013 hSenid International (pvt) Limited.
 *   All Rights Reserved.
 *
 *   These materials are unpublished, proprietary, confidential source code of
 *   hSenid International (pvt) Limited and constitute a TRADE SECRET of hSenid
 *   International (pvt) Limited.
 *
 *   hSenid International (pvt) Limited retains all title to and intellectual
 *   property rights in these materials.
 */

    $APP_ID = "APP_000017";
    $PASSWORD = "95904999aa8edb0c038b3295fdd271de";
    $EXTERNAL_TRX_ID = "12345678901234567890123456789012";
    $PAYMENT_INSTRUMENT_NAME = "MobileAccount";
    $ACCOUNT_ID = "123456";
    $CURRENCY ="LKR";
//    $SEVER_URL_QUERY_BALANCE_SENDER = "http://localhost:7000/caas/balance/query";
//    $SEVER_URL_DIRECT_DEBIT_SENDER = "http://127.0.0.1:7000/caas/direct/debit";
//  If application sms-mt sending https url used urls as below
    $SEVER_URL_QUERY_BALANCE_SENDER = "https://localhost:7443/caas/balance/query";
    $SEVER_URL_DIRECT_DEBIT_SENDER = "https://127.0.0.1:7443/caas/direct/debit";
 ?>