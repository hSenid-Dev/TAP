<?php  
	mysqli_connect("localhost", "siyas2310517", "3c2#siyasShareef230447","siyas2310517_db" )or die(mysql_error()); 
?>



