<?php
/**
 *   (C) Copyright 1997-2013 hSenid International (pvt) Limited.
 *   All Rights Reserved.
 *
 *   These materials are unpublished, proprietary, confidential source code of
 *   hSenid International (pvt) Limited and constitute a TRADE SECRET of hSenid
 *   International (pvt) Limited.
 *
 *   hSenid International (pvt) Limited retains all title to and intellectual
 *   property rights in these materials.
 */

$APP_ID = "APP_000957";
$PASSWORD = "a98afd65d57961b21ef2114eafc5aa43";
$SUBSCRIBER_ID = "tel:94776177393";
$SERVICE_TYPE = "IMMEDIATE";
$RESPONSE_TIME ="DELAY_TOLERANCE";
$FRESHNESS = "LOW";
$HORIZONTAL_ACCURACY = "1000";

$LBS_QUERY_SERVER_URL = "http://127.0.0.1:7000/lbs/locate";
